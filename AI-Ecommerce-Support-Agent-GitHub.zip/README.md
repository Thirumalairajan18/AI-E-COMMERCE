# AI E-Commerce Customer Support Agent

An Agentic AI customer-support assistant for an e-commerce store, built as an academic project (IBM Internship — Agentic AI use case). The agent handles product queries, order-status lookups, returns, and product recommendations using **tool calling** and **memory**.

> Academic project · G. Thirumalai Rajan · Dept. of Computer Science and Engineering · ULTRA College of Engineering and Technology · 2026

## Live demo

Open [`app/index.html`](app/index.html) directly in a browser, or enable **GitHub Pages** for this repo (Settings → Pages → Deploy from branch → `main` → `/app`) to get a shareable link.

## Key capabilities

| Capability | Description |
|---|---|
| **Tool Calling** | The agent calls dedicated functions for order lookup, returns, and recommendations instead of guessing answers. |
| **Memory** | Facts about the customer (name, preferences, order in focus) are saved and recalled across the conversation, persisted in browser storage. |

## Agentic workflow

```
Customer Query → Intent Understanding → Memory Check → Tool Selection → Tool Execution → Response Generation
```

## Tools implemented

- `get_order_status(order_id)` — looks up order status, item, and expected delivery
- `initiate_return(order_id, reason)` — checks return eligibility and returns the return steps
- `recommend_products(query, max_price)` — matches products to a customer's stated needs
- `get_product_info(product_name)` — returns details for a specific product
- `save_customer_memory(key, value)` / `get_customer_memory()` — persists and recalls customer context

## Try it

Sample messages to type into the chat:

- "Where is my order ORD-48210?"
- "I want to return my order ORD-30056, the item doesn't fit."
- "I need a lightweight laptop bag under ₹2000 for my daily commute."
- "Tell me about the FeatherLite Sling Laptop Bag."

Every tool call is shown live in the chat (e.g. `calling tool: get_order_status()`) so the interaction is easy to demo or walk through in a viva.

## Project structure

```
.
├── app/
│   └── index.html        # The working agent app (single-file HTML/JS)
├── docs/
│   └── Project_Report.pdf # Full academic project report
├── LICENSE
└── README.md
```

## Tech notes

- Single-file HTML/CSS/JS — no build step, no dependencies to install.
- The agent's reasoning is powered by the Claude API (Anthropic), called client-side with a defined tool schema.
- Order and product data are mocked in-file to simulate a real e-commerce backend, per the project's use-case specification.
- Requires an internet connection to reach the API when running live.

## Future enhancements

- Customer authentication for secure access to real order data
- Live inventory, delivery tracking, and payment integrations
- Multilingual support
- Human-agent handoff for complex cases
- Analytics on support intents and performance
